<?php
define('HOST','localhost');
define('USER','root');
define('PASS','');
define('DB1', 'm_proyek');

$konek = new mysqli(HOST, USER, PASS, DB1);
?>