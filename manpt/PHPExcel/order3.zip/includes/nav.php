<aside class="left-sidebar" data-sidebarbg="skin6">
	<div class="scroll-sidebar">
		<nav class="sidebar-nav">
			<ul id="sidebarnav">
				<li class="sidebar-item"> 
					<a class="sidebar-link waves-effect waves-dark sidebar-link" href="index.php" aria-expanded="false">
						<i class="fas fa-clock fa-fw" aria-hidden="true"></i>
						<span class="hide-menu">Dashboard</span>
					</a>
				</li>
				<li class="sidebar-item"> 
					<a class="sidebar-link waves-effect waves-dark sidebar-link" href="user.php" aria-expanded="false">
						<i class="fa fa-user" aria-hidden="true"></i>
						<span class="hide-menu">User</span>
					</a>
				</li>
				<li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="proyek.php" aria-expanded="false">
					<i class="fas fa-database" aria-hidden="true"></i>
					<span class="hide-menu">Proyek</span></a>
				</li>
				<li class="sidebar-item"> 
					<a class="sidebar-link waves-effect waves-dark sidebar-link" href="logout.php" aria-expanded="false">
						<i class="fas fa-user-times" aria-hidden="true"></i>
						<span class="hide-menu">Logout</span>
					</a>
				</li>
			</ul>
		</nav>
	</div>
</aside>