<?php
include('koneksi.php');

if(isset($_POST['saveprogress'])){
	$progress = $_POST['progress'];
	$new_array = array(null, null, null, null, null);
	$null = array(null, null, null, null, null);

	$loop = count($progress);
	for($i=0; $i<5-$loop; $i++) array_push($progress, $null[$i]);
		
	$beres = 0;
	for($i=0; $i<5; $i++){
		for($j=0; $j<$loop; $j++){
			if($progress[$j] == $i){
				$new_array[$i] = "1";
				$beres++;
			}elseif($new_array[$i] == null){
				$new_array[$i] = "0";
			}
		}
	}

	$progress = json_encode($new_array);
	if($beres == 5){
		$proses = mysqli_query($konek, "UPDATE proyek SET progress='$progress', status = 'Selesai' WHERE id='$_POST[id]'");
		if($proses) header("location: proyek.php?pesan=".base64_encode("Progress Berhasil Diubah"));
	}else{
		$proses = mysqli_query($konek, "UPDATE proyek SET progress='$progress' WHERE id='$_POST[id]'");
		if($proses) header("location: proyek.php?pesan=".base64_encode("Progress Berhasil Diubah"));
	}
}

if(isset($_GET['id']) && isset($_GET['progress'])){
	$beres = '["1","1","1","1","1"]';
	$proses = mysqli_query($konek, "UPDATE proyek SET progress='$beres', status = 'Selesai' WHERE id='$_GET[id]'");
	if($proses) header("location: proyek.php?pesan=".base64_encode("Progress Berhasil Diubah"));
}
if(isset($_GET['id']) && isset($_GET['hapus'])){
	$proses = mysqli_query($konek, "DELETE FROM proyek WHERE id='$_GET[id]'");
	if($proses) header("location: proyek.php?pesan=".base64_encode("Proyek Berhasil Dihapus"));
}

if(isset($_POST['updateproyek'])){
	function tanggal_proyek($tanggal){
		$pecah = explode('-',$tanggal);
		return $pecah[0]."-".$pecah[1]."-".$pecah[2];
	}
	$progress = json_encode(array(0,0,0,0,0));
	$mulai = tanggal_proyek($_POST['mulai']);
	$beres = tanggal_proyek($_POST['beres']);
	$masuk_data = mysqli_query($konek, "UPDATE proyek SET nama_proyek='$_POST[nama_proyek]', nama_barang='$_POST[nama_barang]', jumlah_barang='$_POST[jumlah_barang]', supplier='$_POST[supplier]', estimasi_pengerjaan='$_POST[estimasi_pengerjaan]', estimasi_biaya='$_POST[estimasi_biaya]', start='$mulai', end='$beres', progress='$progress' WHERE id='$_POST[id]'");
	if($masuk_data) header("location: proyek.php?pesan=".base64_encode("Data Proyek Berhasil Diubah"));

	if(($masuk_data) AND ($_FILES['uploadlaporan']['name'] != "")){
		$errors= array();
		  
		  $file_size =$_FILES['uploadlaporan']['size'];
		  $file_tmp =$_FILES['uploadlaporan']['tmp_name'];
		  $file_type=$_FILES['uploadlaporan']['type'];
		  $tmp = explode('.',$_FILES['uploadlaporan']['name']);
		  $file_ext=strtolower(end($tmp));
		  $file_name = "laporan".$_POST['id'].".".$file_ext;
		  
		  $extensions= array("pdf");
		  
		  if(in_array($file_ext,$extensions)=== false) $errors[]="extension not allowed, please choose a JPEG or PNG file.";
		  
		  if(empty($errors)==true){
			 move_uploaded_file($file_tmp,"uploads/".$file_name);
			 if(mysqli_query($konek, "UPDATE proyek SET laporan = '$file_name' WHERE id = '$$_POST[id]'")) header("location: proyek.php?pesan=".base64_encode("Data Proyek Berhasil Diubah"));
		  }else print_r($errors);
	}
}

if(isset($_POST['tambahproyek'])){
	
	function tanggal_proyek($tanggal){
		$pecah = explode('-',$tanggal);
		return $pecah[0]."-".$pecah[1]."-".$pecah[2];
	}
	$progress = json_encode(array(0,0,0,0,0));
	$mulai = tanggal_proyek($_POST['mulai']);
	$beres = tanggal_proyek($_POST['beres']);
	$sekarang = strtotime(date("Y-m-d"));
	if($sekarang < strtotime($mulai)) $status ="Akan Berjalan"; else $status="Berjalan";
	$masuk_data = mysqli_query($konek, "INSERT INTO proyek (nama_proyek,nama_barang,jumlah_barang,supplier,estimasi_pengerjaan,estimasi_biaya,start,end,progress,laporan,status) VALUES('$_POST[nama_proyek]','$_POST[nama_barang]','$_POST[jumlah_barang]','$_POST[supplier]','$_POST[estimasi_pengerjaan]','$_POST[estimasi_biaya]','$mulai','$beres','$progress','','$status')");

	if($masuk_data){ 
		$idakhir = implode(" ", mysqli_fetch_assoc(mysqli_query($konek, "SELECT id FROM proyek ORDER BY id DESC LIMIT 1")));
		$errors= array();
		  
		  $file_size =$_FILES['uploadlaporan']['size'];
		  $file_tmp =$_FILES['uploadlaporan']['tmp_name'];
		  $file_type=$_FILES['uploadlaporan']['type'];
		  $tmp = explode('.',$_FILES['uploadlaporan']['name']);
		  $file_ext=strtolower(end($tmp));
		  $file_name = "laporan".$idakhir.".".$file_ext;
		  
		  $extensions= array("pdf");
		  
		  if(in_array($file_ext,$extensions)=== false) $errors[]="extension not allowed, please choose a JPEG or PNG file.";
		  
		  if(empty($errors)==true){
			 move_uploaded_file($file_tmp,"uploads/".$file_name);
			 if(mysqli_query($konek, "UPDATE proyek SET laporan = '$file_name' WHERE id = '$idakhir'")) header("location: proyek.php?pesan=".base64_encode("Proyek Berhasil Ditambahkan"));
		  }else print_r($errors);
	}
}

if(isset($_POST['edituser'])){
	if(mysqli_query($konek, "UPDATE users SET nama='$_POST[nama]', email='$_POST[email]', telp='$_POST[telp]' WHERE id_user='$_POST[id]'")) header("location: user.php?pesan=".base64_encode("Data Berhasil Diubah"));
}

if(isset($_POST['cekusername'])){
	echo mysqli_fetch_array(mysqli_query($konek, "SELECT COUNT(*) AS hitung FROM users WHERE username = '$_POST[cekusername]'"))['hitung'];
}

if(isset($_POST['tambahuser'])){
	if(mysqli_fetch_array(mysqli_query($konek, "SELECT COUNT(*) AS hitung FROM users WHERE username = '$_POST[username]'"))['hitung'] <= 0){
		$password = md5($_POST['password']);
		if(mysqli_query($konek, "INSERT INTO users (username,nama,email,level,password,telp) VALUES('$_POST[username]','$_POST[nama]','$_POST[email]','$_POST[level]','$password','$_POST[telp]')")) header("location: tambahuser.php?pesan=".base64_encode("User Berhasil Ditambahkan"));
	}else{
		header("location: tambahuser.php?pesan=".base64_encode("Username Sudah Ada"));
	}
}

if(isset($_POST['ubahpassword'])){
	if(md5($_POST['password_baru']) == md5($_POST['konfirmasi_password'])){
		$password_lama = mysqli_fetch_array(mysqli_query($konek, "SELECT password FROM users WHERE id_user='$_POST[id]'"));
		$password = md5($_POST['password_baru']);
		if(md5($_POST['password_lama']) === $password_lama['password']){
			if(mysqli_query($konek, "UPDATE users SET password='$password' WHERE id_user='$_POST[id]'")) header("location: ubahpassword.php?pesan=".base64_encode("Password Berhasil Diubah"));
		}else{
			header("location: ubahpassword.php?pesan=".base64_encode("Password Lama Salah"));
		}
	}else{
		header("location: ubahpassword.php?pesan=".base64_encode("Password Tidak Cocok"));
	}

}

?>